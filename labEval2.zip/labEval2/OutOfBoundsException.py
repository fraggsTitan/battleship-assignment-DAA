class OutOfBoundsException(Exception):
    pass