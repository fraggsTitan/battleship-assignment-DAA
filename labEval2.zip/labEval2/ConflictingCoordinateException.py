class ConflictingCoordinateException(Exception):
    pass